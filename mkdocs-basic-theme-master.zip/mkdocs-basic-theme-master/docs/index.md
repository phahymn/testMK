# MkDocs Basic Theme

This is a very basic theme for MkDocs with the goal of demonstrating all of
the features with minimal HTML and CSS.

## Adapting this theme

If you want to use this theme as a base to create your own, it is best to
download or fork the theme and start to modify it

Make sure you read the MkDocs documentation regarding writing custom themes.
