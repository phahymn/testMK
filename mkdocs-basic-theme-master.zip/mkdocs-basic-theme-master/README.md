# MkDocs Basic Theme

This is an example minimal theme for MkDocs. You can see it running with a
build for this documentation. However, note that it is intended as a code
example rather than an example of a usable theme.

https://mkdocs.github.io/mkdocs-basic-theme/

[![PyPI Downloads][pypi-dl-image]][pypi-dl-link]
[![PyPI Version][pypi-v-image]][pypi-v-link]

[pypi-dl-image]: https://img.shields.io/pypi/dm/mkdocs-basic-theme.png
[pypi-dl-link]: https://pypi.python.org/pypi/mkdocs-basic-theme
[pypi-v-image]: https://img.shields.io/pypi/v/mkdocs-basic-theme.png
[pypi-v-link]: https://pypi.python.org/pypi/mkdocs-basic-theme

